package dev.anvilcraft.resource.ageratum.client.feat.markdown.component;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.anvilcraft.resource.ageratum.client.feat.markdown.MDRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.Nullable;

/**
 * Markdown 标题组件。
 *
 * <p>支持 ATX 形式标题（{@code # ~ ######}），并根据标题级别调整缩放比例。</p>
 */
public class MDHeaderComponent extends MDComponent {
    private static final Pattern HEADER_PATTERN = Pattern.compile("^\\s{0,3}(#{1,6})\\s+(.+?)\\s*#*\\s*$");
    /**
     * 标题级别（1-6）。
     */
    protected final int level;

    /**
     * 创建标题组件。
     *
     * @param level 标题级别（1-6）
     * @param text  标题文本
     */
    public MDHeaderComponent(int level, String text) {
        super(MDComponent.textFormat(text, MDHeaderComponent.getStyle(level)));
        this.level = level;
    }

    /**
     * 尝试从单行文本解析标题组件。
     */
    @Nullable
    public static MDHeaderComponent parse(ResourceLocation sourceLocation, String text) {
        Matcher matcher = HEADER_PATTERN.matcher(text);
        if (!matcher.matches()) return null;
        int level = matcher.group(1).length();
        String headerText = matcher.group(2).trim();
        return new MDHeaderComponent(level, headerText);
    }

    /**
     * 按标题级别计算渲染缩放比例。
     */
    private float getScale() {
        return switch (this.level) {
            case 1 -> 2.0F;
            case 2 -> 1.5F;
            default -> 1.0F;
        };
    }

    private static Style getStyle(int level) {
        Style style = Style.EMPTY;
        if (level % 2 != 0) {
            return style.withBold(true);
        }
        return style;
    }

    private int scale(int value) {
        return (int) Math.ceil(value * this.getScale());
    }

    private int unscale(int value) {
        return (int) Math.floor(value / this.getScale());
    }

    /**
     * 渲染标题文本；一级标题额外绘制一条分隔线。
     */
    @Override
    public void render(MDRenderContext context) {
        Minecraft minecraft = context.minecraft();
        int maxX = context.maxX();
        int maxY = context.maxY();
        float mouseX = context.mouseX();
        float mouseY = context.mouseY();
        GuiGraphics guiGraphics = context.graphics();
        PoseStack pose = guiGraphics.pose();
        pose.pushPose();
        float scale = this.getScale();
        pose.scale(scale, scale, scale);
        super.render(context.child(this.unscale(maxX), this.unscale(maxY), mouseX / scale, mouseY / scale, scale));
        if (this.level == 1) {
            int y = minecraft.font.lineHeight / 2;
            guiGraphics.hLine(0, Math.max(0, maxX - 1), y, -2013265920);
        }
        pose.popPose();
    }

    /**
     * 计算标题渲染高度（含一级标题分隔线高度）。
     */
    @Override
    public int getHeight(Minecraft minecraft, int maxX, int maxY) {
        int height = this.scale(super.getHeight(minecraft, this.unscale(maxX), this.unscale(maxY)));
        if (this.level == 1) {
            height += minecraft.font.lineHeight;
        }
        return height;
    }

    /**
     * 标题级别（1-6）。
     */
    public int getLevel() {
        return this.level;
    }
}
