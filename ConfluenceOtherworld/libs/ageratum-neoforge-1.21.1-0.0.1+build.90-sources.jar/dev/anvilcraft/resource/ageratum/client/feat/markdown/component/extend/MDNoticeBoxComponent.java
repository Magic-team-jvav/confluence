package dev.anvilcraft.resource.ageratum.client.feat.markdown.component.extend;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.anvilcraft.resource.ageratum.client.feat.markdown.MDRenderContext;
import dev.anvilcraft.resource.ageratum.client.feat.markdown.component.MDComponent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.Style;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;

/**
 * 提示框组件（info、tip、warning、danger）。
 *
 * <p>渲染带背景颜色和边框的提示区块，用于强调特定类型的内容。</p>
 */
public class MDNoticeBoxComponent extends MDComponent {
    private static final int PADDING = 8;
    private static final int BORDER_WIDTH = 3;
    private final NoticeType type;
    private final List<MDComponent> contentComponents;


    /**
     * 提示框类型与相关颜色配置。
     */
    public enum NoticeType {
        INFO(-12877066, -1428230665),  // 蓝色
        TIP(-15681151, -1429080600),  // 绿色
        WARNING(-680437, -1426132025),  // 橙色
        DANGER(-1096636, -1426136350);
        // 红色
        private final int borderColor;
        private final int backgroundColor;

        NoticeType(int borderColor, int backgroundColor) {
            this.borderColor = borderColor;
            this.backgroundColor = backgroundColor;
        }

        public int getBorderColor() {
            return this.borderColor;
        }

        public int getBackgroundColor() {
            return this.backgroundColor;
        }
    }

    /**
     * 创建提示框组件。
     */
    public MDNoticeBoxComponent(NoticeType type, List<MDComponent> contentComponents) {
        super(buildComponentText(contentComponents));
        this.type = type;
        this.contentComponents = List.copyOf(contentComponents);
    }

    @Override
    public void render(MDRenderContext context) {
        Minecraft minecraft = context.minecraft();
        int maxX = context.maxX();
        int maxY = context.maxY();
        float mouseX = context.mouseX();
        float mouseY = context.mouseY();
        GuiGraphics guiGraphics = context.graphics();
        if (this.contentComponents.isEmpty()) {
            return;
        }
        int boxHeight = this.getHeight(minecraft, maxX, maxY);
        int contentWidth = Math.max(1, maxX - PADDING * 2 - BORDER_WIDTH);
        // 绘制背景
        guiGraphics.fill(0, 0, maxX, boxHeight, this.type.getBackgroundColor());
        // 绘制左侧边框
        guiGraphics.fill(0, 0, BORDER_WIDTH, boxHeight, this.type.getBorderColor());
        // 绘制内容
        PoseStack pose = guiGraphics.pose();
        pose.pushPose();
        int translateX = PADDING + BORDER_WIDTH;
        pose.translate(translateX, PADDING, 0);
        for (MDComponent component : this.contentComponents) {
            component.render(context.child(contentWidth, Integer.MAX_VALUE, mouseX - translateX, mouseY - PADDING, 1.0F));
            int componentHeight = component.getHeight(minecraft, contentWidth, Integer.MAX_VALUE);
            pose.translate(0, componentHeight, 0);
        }
        pose.popPose();
    }

    @Override
    public int getHeight(Minecraft minecraft, int maxX, int maxY) {
        int contentWidth = Math.max(1, maxX - PADDING * 2 - BORDER_WIDTH);
        int totalHeight = 0;
        for (MDComponent component : this.contentComponents) {
            totalHeight += component.getHeight(minecraft, contentWidth, Integer.MAX_VALUE);
        }
        return totalHeight + PADDING * 2;
    }

    @Override
    @Nullable
    public Style getStyleAtPosition(Minecraft minecraft, double mouseX, double mouseY, int maxX) {
        if (mouseX < 0 || mouseY < 0 || this.contentComponents.isEmpty()) {
            return null;
        }
        int contentOriginX = PADDING + BORDER_WIDTH;
        int contentWidth = Math.max(1, maxX - PADDING * 2 - BORDER_WIDTH);
        double contentMouseX = mouseX - contentOriginX;
        double contentMouseY = mouseY - PADDING;
        if (contentMouseX < 0 || contentMouseY < 0) {
            return null;
        }
        double currentY = 0;
        for (MDComponent component : this.contentComponents) {
            int componentHeight = component.getHeight(minecraft, contentWidth, Integer.MAX_VALUE);
            if (contentMouseY >= currentY && contentMouseY < currentY + componentHeight) {
                return component.getStyleAtPosition(minecraft, contentMouseX, contentMouseY - currentY, contentWidth);
            }
            currentY += componentHeight;
        }
        return null;
    }

    private static FormattedText buildComponentText(List<MDComponent> contentComponents) {
        if (contentComponents.isEmpty()) {
            return FormattedText.EMPTY;
        }
        List<FormattedText> parts = new ArrayList<>(contentComponents.size() * 2);
        for (int i = 0; i < contentComponents.size(); i++) {
            parts.add(contentComponents.get(i).getText());
            if (i < contentComponents.size() - 1) {
                parts.add(FormattedText.of("\n"));
            }
        }
        return FormattedText.composite(parts);
    }
}
